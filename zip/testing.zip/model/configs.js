import saveToCSV from "../logs/csv.js";


class Timer {
   constructor() {
      this.batch = 0;
      this.Torder = 0;
      this.Forder = 0; // Finished Order
      this.Ttime = 0;
   }
}

class Logs{

   constructor(){
      this.logs = [];
      this.s = Date.now();
   }

   addLog(data){
      this.logs.push(data)
   }

   saveLog(file){
      console.log("Writing into CSV")
      let TimeofExecution = Date.now() - this.s;
      console.log("Before Writing CSV Time Of Execution : ",TimeofExecution +"ms")

      saveToCSV(this.logs,file)
      TimeofExecution = Date.now() - this.s;
      console.log("Time Of Execution : ",TimeofExecution +"ms")
      process.exit()
   }

}
const TimeOut = 60000;
const timer = new Timer();
const logs = new Logs();
export {timer,logs,TimeOut};