import {timer} from "./configs.js";

export default class Order {
    constructor(url, browser) {
        this.url = url;
        this.start = 0;
        timer.Torder++;
        this.id = timer.Torder;
        this.time = 0;
        this.browser = browser;
        this.context = null;
        this.page = null;
        this.title = "";
        this.length = 0;
        this.code = 0;
        this.write = false;
    }

    async initialize() {
        this.context = await this.browser.createBrowserContext();
        this.page = await this.context.newPage();
        // await this.page.setCacheEnabled(false);
        this.log("Init Done")
        this.start= Date.now()
    }

    timeStramp() {
        let now = new Date();
        return now.toString() + " " + now.getMilliseconds() + "ms";
    }

    setLength(len) {
        this.length = len;
    }

    getUrl() {
        return this.url;
    }

    setTitle(title) {
        this.title = title;
    }

    setCode(code) {
        this.code = code;
    }

    getPage() {
        return this.page;
    }

    getContext() {
        return this.context;
    }
    
    calcTime(){
        if(this.time==0){
            this.time = Date.now() - this.start;
            timer.Ttime+=this.time
            timer.Forder++;
        }
        return this.getTime()
    }
    getTime(){
        return this.time
    }

    log(msg) {
        console.log(this.timeStramp(),"ID : ",this.id, " Title : ", this.title, " URL : ", this.url, "MSG : ", msg);
    }

    logTime(msg){
        console.log(this.timeStramp(),"ID : ",this.id," URL : ", this.url,"Time Taken : ", this.time ,"ms :-> ", msg);

    }

    logEnd() {
        console.log(this.timeStramp(),"ID : ",this.id, " Code : ", this.code, " Title : ", this.title || "Not Fetched", " Length : ", this.length);
        
    }
}