import { EventEmitter } from "events";

export default class Emitter extends EventEmitter {
    constructor() {
        super();

        this.on("getOrder", async (order) => {
            try {
                order.log("END OF LOG");
                order.logEnd();
                await order.getContext().close();
                order.log("ENDED!!");
            } catch (error) {
                order.log("ERROR : getOrder : " + error.message);

            }

        });

        this.on("scrap", async (order) => {

            try {
                let url = order.getUrl();
                let page = order.getPage();
                order.log("GOTO Started");
                let res = await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });
                order.setCode(res.status());
                order.setTitle(await page.title());
                order.log("Title Extracted");
                order.log("GOTO Finished");
                this.emit("dscrap", order);

            } catch (error) {
                order.log("ERROR : Scrap : " + error.message);

            }

        });

        this.on("dscrap", async (order) => {
            try {
                order.log("Extraction Started");
                let page = order.getPage();
                let content = await page.content();
                order.setLength(content.length);
                order.log("Extraction Done!!");

                this.emit("getOrder", order);

            } catch (error) {
                order.log("ERROR : DScrap : " + error.message);

            }
        });
    }
}
