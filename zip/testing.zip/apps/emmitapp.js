// import Order from "../model/order.js";
import Order from "../model/Eorder.js";
import puppeteer from "puppeteer";
import Emitter from "../emitter/orderemmiter.js";
import { open } from 'node:fs/promises';

const browser = await puppeteer.launch({ headless: true, devtools: false, args: ['--no-sandbox', '--disable-setuid-sandbox'], })



let emitter = new Emitter();

async function app() {
    return async (url) => {
        try {
            let order = new Order(url, browser);
            await order.initialize();
            emitter.emit('scrap', order);
        } catch (err) {
            console.log("Error At : ", url, " Error : ", err)
        }


    };
}

// export default async function emmitapp() {

//     const start = await app();
//     console.log("Started");
//     let url = 'https://www.wikipedia.org/';

//     await start(url);

//     // await browser.close(); 
// }



const start = await app()
let batch = []
let Bcount = 0;
async function exeBatch(urls) {
    try {

        console.log("Batch ", Bcount+1," Strated");
        
        await Promise.all([
            start(urls[0]),
            start(urls[1]),
            start(urls[2]),
            start(urls[3]),
        ]);
        Bcount++;
    } catch (err) {
        console.log(err, "Batch : ",Bcount+1);
    }
}


let count = 0
console.log("Strated")
while (count < 1) {
    const file =  await open('./sample.csv');

    batch.length = 0;
    
    try {
        for await (const line of file.readLines()) {
            
            batch.push(line);
            
            if (batch.length > 3) {
                await exeBatch(batch);
                batch.length = 0;

            }
            
        }

    } finally {
        await file.close();
    }

    console.log("File Occurance : ",count+1," Completed");
    count++;
}

