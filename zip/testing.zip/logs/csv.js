import { writeFileSync } from 'fs';

export default function saveToCSV(data, fileName = 'output.csv') {
    fileName = "csv/"+fileName
    let csvContent = "S.N,Batch Count,Total Order,URL,Title,Length,Time Taken(ms)\n";
    
    data.forEach((item, index) => {
        let sn = index + 1;
        
        csvContent += `${sn},${item.batchCount},${item.totalOrder},${item.url},${item.title.length==0?"Error or No Title":item.title.replace(/,/g, '')},${item.len},${item.timeTaken}\n`;
    });

    writeFileSync(fileName, csvContent);
    console.log(`Values saved to ${fileName}`);
}

